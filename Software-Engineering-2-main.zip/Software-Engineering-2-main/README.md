# Courses Management System
This system helps to manage student, instructor and rooms in any educational place. It mainly contains important modules like
1. Admin Module
a) Login and logout (when login student, instructor, and admin see view different for
each other).
b) The Admin can (Add, Update, delete) student or instructor and users.
2. Courses Module
a) (Add, delete, update) parent courses.
b) Show all Instructor.
c) Show all students.
d) Create page to save courses with its details (instructor, room, branch, price, parent
course, price, students, and grades of course, start date, days of course, end date).
e) Report to display courses that near to start.
f) Report to display courses that near to end.
3. Student Module
a) See his grades of specific course.
b) Make survey about specific course.
c) See all courses and update his information.
4. Instructor Module
a) Can add grades and publish.
